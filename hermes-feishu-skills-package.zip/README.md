# 飞书 Lark CLI 技能包

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-macOS%20%7C%20Linux%20%7C%20Windows-lightgrey)](https://github.com)

一套基于 `lark-cli` 命令行工具的飞书操作技能套件，支持文件发送、消息发送、文档创建与更新。

---

## ✨ 特性

- **跨平台**：支持 macOS、Linux、WSL、Windows（PowerShell/CMD）
- **多 Hermes 衍生版兼容**：Hermes / OpenClaw / Codex / Claude Code / AMP / OpenCode
- **标准化部署**：包含 package.json、MANIFEST.json，符合 Node.js 生态规范
- **自动检测**：安装脚本自动识别平台和 Hermes 版本
- **一键安装**：`npm install` 风格或直接运行平台脚本

---

## 📦 包含的技能

```
skills/
└── messaging/
    ├── feishu-file-send-lark-cli/      # 发送本地文件到飞书会话
    ├── feishu-message-send-lark-cli/   # 发送文本/富文本消息
    └── feishu-doc-create-lark-cli/     # 创建/更新飞书云文档
```

每个技能都包含完整的 SKILL.md 文档，可在 Hermes CLI 中通过 `/skill-name --help` 查看。

---

## 🚀 快速开始

### 前置条件

| 组件 | 最低版本 | 说明 |
|------|---------|------|
| Node.js | v18+ | 运行 lark-cli |
| lark-cli | latest | 飞书官方 CLI 工具 |
| Hermes 平台 | v2.0+ | 或 OpenClaw/Codex/Claude Code 等 |

### 一键安装（推荐）

```bash
# 1. 下载技能包（ZIP 或 Git）
# 从飞书 DM 下载 feishu-lark-cli-skills.zip 并解压

cd feishu-skills-package

# 2. 自动检测平台并安装（推荐）
./scripts/install.sh

# 或指定平台
./scripts/install.sh hermes      # Hermes Agent
./scripts/install.sh openclaw    # OpenClaw
./scripts/install.sh codex       # OpenAI Codex CLI
./scripts/install.sh claude      # Claude Code
./scripts/install.sh amp         # AMP
./scripts/install.sh opencode    # OpenCode

# Windows
powershell -ExecutionPolicy Bypass -File scripts\install.ps1 hermes
# 或
scripts\install.bat hermes
```

### 手动安装

#### Hermes 平台

```bash
# 方式1：使用 hermes 命令
hermes skills install /path/to/feishu-skills-package

# 方式2：复制到技能目录
cp -r skills/messaging ~/.hermes/skills/
hermes skills reload
```

#### OpenClaw

```bash
openclaw skills install /path/to/feishu-skills-package
```

#### Codex

```bash
codex skills install /path/to/feishu-skills-package
```

#### Claude Code

```bash
claude skills install /path/to/feishu-skills-package
```

#### AMP

```bash
amp skills install /path/to/feishu-skills-package
```

#### OpenCode

```bash
opencode skills install /path/to/feishu-skills-package
```

---

## 🎯 使用方法

### 在 Hermes CLI 中

```bash
# 启动 Hermes
hermes

# 发送文件到飞书 DM
/feishu-file-send-lark-cli --file "/path/to/report.md" --chat-id oc_xxx

# 发送文本消息
/feishu-message-send-lark-cli --text "你好，这是报告" --chat-id oc_xxx

# 发送 Markdown 富文本
/feishu-message-send-lark-cli --markdown "**加粗** *斜体*" --chat-id oc_xxx

# 创建飞书云文档（从 Markdown 文件）
# 先获取父文件夹 token
lark-cli drive files list --format json | python -m json.tool
# 找到目标文件夹的 token，如 "病情": GQC6f9gcylTLPOdcj6FcahpQn7d

/feishu-doc-create-lark-cli --create --title "调研报告" --folder GQC6f9gcylTLPOdcj6FcahpQn7d --markdown @report.md

# 更新现有文档
/feishu-doc-create-lark-cli --update --doc-id ILAudNLOuoQdKlxpK1mcZDIqnXc --markdown @report.md
```

### 直接调用 lark-cli

```bash
# 1. 找到 chat_id（DM 或群聊）
lark-cli im +messages-search --query "" --format json | python -m json.tool
# 取第一条的 chat_id 字段

# 2. 发送文件（必须先复制到 lark-cli 工作目录）
cp /path/to/file.md $(dirname $(which lark-cli))/
lark-cli im +messages --as user --chat-id oc_xxx --file file.md --format json

# 3. 发送消息
lark-cli im +messages-send --as user --chat-id oc_xxx --content '{"text":"消息内容"}' --format json
```

---

## 🔧 获取 chat_id

DM（私信）的 chat_id 不能通过 `im chats list` 获取（只显示群聊），需要使用消息搜索：

```bash
# 方法A：搜索最近消息（推荐）
lark-cli im +messages-search --query "" --format json | python -m json.tool
# 从返回的 messages[0].chat_id 提取

# 方法B：通过 user_id 查找（知道对方 user_id 时）
lark-cli im +chats-create --user-id ou_xxx --format json
```

---

## 🛠️ 故障排除

### lark-cli 未登录

```bash
lark-cli auth logout
lark-cli auth login
# 按提示扫码
```

### 文件找不到

--file 参数要求文件在 lark-cli 当前工作目录，不支持绝对路径：

```bash
# 错误方式
lark-cli ... --file /abs/path/file.md

# 正确方式
cd $(dirname $(which lark-cli))
cp /abs/path/file.md .
lark-cli ... --file file.md
```

### 权限错误（bot vs user）

```bash
# 默认 --as bot，无文件上传权限
lark-cli im +messages-send --chat-id oc_xxx --file file.md

# 必须指定 --as user
lark-cli im +messages-send --as user --chat-id oc_xxx --file file.md
```

### Hermes 未识别新技能

```bash
hermes skills list        # 查看已加载技能
hermes skills reload      # 重载技能
hermes restart            # 重启 Hermes
```

### Windows 路径问题

PowerShell 中路径含空格需加引号：

```powershell
.\install.ps1 "C:\Users\Me\Downloads\feishu-lark-cli-skills.zip"
```

---

## 📁 项目结构

```
feishu-skills-package/
├── LICENSE                          # MIT License
├── README.md                        # 本文档
├── MANIFEST.json                    # 技能清单（平台识别用）
├── package.json                     # Node.js 包配置
├── scripts/
│   ├── install.sh                   # macOS/Linux/WSL 安装脚本
│   ├── install.ps1                  # Windows PowerShell 安装脚本
│   └── install.bat                  # Windows CMD 安装脚本
└── skills/
    └── messaging/
        ├── feishu-file-send-lark-cli/
        │   └── SKILL.md             # 文件发送技能文档
        ├── feishu-message-send-lark-cli/
        │   └── SKILL.md             # 消息发送技能文档
        └── feishu-doc-create-lark-cli/
            └── SKILL.md             # 文档创建技能文档
```

---

## 🔄 版本兼容性

| Hermes 平台 | 最低版本 | 测试状态 |
|------------|---------|---------|
| Hermes Agent | v2.0.0 | 兼容 |
| OpenClaw | v1.5.0+ | 兼容 |
| Codex CLI | latest | 兼容 |
| Claude Code | latest | 兼容 |
| AMP | latest | 兼容 |
| OpenCode | latest | 兼容 |

---

## 📚 相关链接

- [Hermes Agent GitHub](https://github.com/ai-playground-zzw/hermes-agent)
- [OpenClaw GitHub](https://github.com/openclaw-ai/openclaw)
- [lark-cli GitHub](https://github.com/larksuite/lark-cli)
- [飞书 Open API](https://open.feishu.cn/document/)

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

```bash
# 本地开发
git clone <repo>
cd hermes-feishu-skills
# 修改技能文件
# 测试: hermes skills install .
```

---

## 📝 变更日志

### v1.0.0 (2026-04-18)
- 初始版本
- 支持文件发送、消息发送、文档创建三个技能
- 兼容 6 个 Hermes 平台
- 提供跨平台安装脚本

---

## ⚖️ License

MIT - 详见 LICENSE 文件
