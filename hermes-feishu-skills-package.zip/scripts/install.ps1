# 通用技能包安装脚本 - Windows (PowerShell)
# 支持: Hermes / OpenClaw / Codex / Claude Code / AMP / OpenCode
# 用法: .\scripts\install.ps1 [platform]
#   platform: hermes, openclaw, codex, claude, amp, opencode, auto(默认)

$ErrorActionPreference = "Stop"

$PLATFORM = $args[0]
if (-not $PLATFORM) { $PLATFORM = "auto" }

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  飞书技能包 - 通用安装脚本" -ForegroundColor Cyan
Write-Host "  平台: Windows" -ForegroundColor Cyan
Write-Host "  支持: Hermes / OpenClaw / Codex / Claude Code / AMP / OpenCode" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
$PROJECT_ROOT = Split-Path -Parent $SCRIPT_DIR

# 自动检测平台
if ($PLATFORM -eq "auto") {
    Write-Host "[INFO] 自动检测平台..." -ForegroundColor Yellow

    if (Get-Command hermes -ErrorAction SilentlyContinue) {
        $PLATFORM = "hermes"
    } elseif (Get-Command openclaw -ErrorAction SilentlyContinue) {
        $PLATFORM = "openclaw"
    } elseif (Get-Command codex -ErrorAction SilentlyContinue) {
        $PLATFORM = "codex"
    } elseif (Get-Command claude -ErrorAction SilentlyContinue) {
        $PLATFORM = "claude-code"
    } elseif (Get-Command amp -ErrorAction SilentlyContinue) {
        $PLATFORM = "amp"
    } elseif (Get-Command opencode -ErrorAction SilentlyContinue) {
        $PLATFORM = "opencode"
    } else {
        Write-Host "[ERROR] 未检测到支持的 Hermes 平台" -ForegroundColor Red
        Write-Host "请手动指定平台或安装 Hermes 系列工具"
        exit 1
    }
}

Write-Host "[INFO] 目标平台: $PLATFORM" -ForegroundColor Green

# 平台特定安装
switch ($PLATFORM) {
    "hermes" {
        Write-Host "运行: hermes skills install ." -ForegroundColor Cyan
        hermes skills install $PROJECT_ROOT
    }
    "openclaw" {
        Write-Host "运行: openclaw skills install ." -ForegroundColor Cyan
        openclaw skills install $PROJECT_ROOT
    }
    "codex" {
        Write-Host "运行: codex skills install ." -ForegroundColor Cyan
        codex skills install $PROJECT_ROOT
    }
    "claude-code" {
        Write-Host "运行: claude skills install ." -ForegroundColor Cyan
        claude skills install $PROJECT_ROOT
    }
    "amp" {
        Write-Host "运行: amp skills install ." -ForegroundColor Cyan
        amp skills install $PROJECT_ROOT
    }
    "opencode" {
        Write-Host "运行: opencode skills install ." -ForegroundColor Cyan
        opencode skills install $PROJECT_ROOT
    }
    default {
        Write-Host "[ERROR] 不支持的平台: $PLATFORM" -ForegroundColor Red
        Write-Host "支持: hermes, openclaw, codex, claude, amp, opencode, auto"
        exit 1
    }
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "✅ 技能包安装完成！" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "下一步："
Write-Host "1. 检查 lark-cli: lark-cli --version"
Write-Host "2. 登录飞书: lark-cli auth login"
Write-Host "3. 测试技能: hermes 然后 /feishu-file-send-lark-cli --help"
Write-Host ""
