#!/bin/bash
# 通用技能包安装脚本 - 支持所有 Hermes 衍生版本
# 用法: ./scripts/install.sh [platform]
#   platform: hermes, openclaw, codex, claude, amp, opencode, auto(默认)

set -e

PLATFORM="${1:-auto}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# 颜色
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo "============================================"
echo "  飞书技能包 - 通用安装脚本"
echo "  支持: Hermes / OpenClaw / Codex / Claude Code / AMP / OpenCode"
echo "============================================"

# 自动检测平台
if [ "$PLATFORM" = "auto" ]; then
    echo -e "${YELLOW}[INFO] 自动检测平台...${NC}"

    if command -v hermes &> /dev/null; then
        PLATFORM="hermes"
    elif command -v openclaw &> /dev/null; then
        PLATFORM="openclaw"
    elif command -v codex &> /dev/null; then
        PLATFORM="codex"
    elif command -v claude &> /dev/null; then
        PLATFORM="claude-code"
    elif command -v amp &> /dev/null; then
        PLATFORM="amp"
    elif command -v opencode &> /dev/null; then
        PLATFORM="opencode"
    else
        echo -e "${RED}[ERROR] 未检测到支持的 Hermes 平台${NC}"
        echo "请手动指定平台或安装 Hermes 系列工具"
        exit 1
    fi
fi

echo -e "${GREEN}[INFO] 目标平台: $PLATFORM${NC}"

# 平台特定安装命令
case "$PLATFORM" in
    hermes)
        echo "运行: hermes skills install ."
        hermes skills install "$PROJECT_ROOT"
        ;;
    openclaw)
        echo "运行: openclaw skills install ."
        openclaw skills install "$PROJECT_ROOT"
        ;;
    codex)
        echo "运行: codex skills install ."
        codex skills install "$PROJECT_ROOT"
        ;;
    claude-code|claude)
        echo "运行: claude skills install ."
        claude skills install "$PROJECT_ROOT"
        ;;
    amp)
        echo "运行: amp skills install ."
        amp skills install "$PROJECT_ROOT"
        ;;
    opencode)
        echo "运行: opencode skills install ."
        opencode skills install "$PROJECT_ROOT"
        ;;
    *)
        echo -e "${RED}[ERROR] 不支持的平台: $PLATFORM${NC}"
        echo "支持: hermes, openclaw, codex, claude, amp, opencode, auto"
        exit 1
        ;;
esac

echo -e "${GREEN}============================================"
echo "✅ 技能包安装完成！"
echo "============================================"
echo ""
echo "下一步："
echo "1. 检查 lark-cli 是否已安装: lark-cli --version"
echo "2. 登录飞书: lark-cli auth login"
echo "3. 测试技能: hermes 然后输入 /feishu-file-send-lark-cli --help"
echo ""
