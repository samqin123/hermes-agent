@echo off
REM 通用技能包安装脚本 - Windows CMD
REM 支持: Hermes / OpenClaw / Codex / Claude Code / AMP / OpenCode
REM 用法: scripts\install.bat [platform]

echo ============================================
echo   飞书技能包 - 通用安装脚本
echo   平台: Windows (CMD)
echo   支持: Hermes / OpenClaw / Codex / Claude Code / AMP / OpenCode
echo ============================================

set "PLATFORM=%~1"
if "%PLATFORM%"=="" set "PLATFORM=auto"

REM 自动检测平台
if "%PLATFORM%"=="auto" (
    echo [INFO] 自动检测平台...
    where hermes >nul 2>nul && set "PLATFORM=hermes" && goto :detected
    where openclaw >nul 2>nul && set "PLATFORM=openclaw" && goto :detected
    where codex >nul 2>nul && set "PLATFORM=codex" && goto :detected
    where claude >nul 2>nul && set "PLATFORM=claude-code" && goto :detected
    where amp >nul 2>nul && set "PLATFORM=amp" && goto :detected
    where opencode >nul 2>nul && set "PLATFORM=opencode" && goto :detected
    echo [ERROR] 未检测到支持的 Hermes 平台
    echo 请手动指定平台或安装 Hermes 系列工具
    exit /b 1
)

:detected
echo [INFO] 目标平台: %PLATFORM%

REM 平台特定安装
if /i "%PLATFORM%"=="hermes" (
    echo 运行: hermes skills install .
    hermes skills install .
) else if /i "%PLATFORM%"=="openclaw" (
    echo 运行: openclaw skills install .
    openclaw skills install .
) else if /i "%PLATFORM%"=="codex" (
    echo 运行: codex skills install .
    codex skills install .
) else if /i "%PLATFORM%"=="claude-code" (
    echo 运行: claude skills install .
    claude skills install .
) else if /i "%PLATFORM%"=="amp" (
    echo 运行: amp skills install .
    amp skills install .
) else if /i "%PLATFORM%"=="opencode" (
    echo 运行: opencode skills install .
    opencode skills install .
) else (
    echo [ERROR] 不支持的平台: %PLATFORM%
    echo 支持: hermes, openclaw, codex, claude, amp, opencode, auto
    exit /b 1
)

echo.
echo ============================================
echo ✅ 技能包安装完成！
echo ============================================
echo.
echo 下一步：
echo   1. 检查 lark-cli: lark-cli --version
echo   2. 登录飞书: lark-cli auth login
echo   3. 测试技能: hermes 然后 /feishu-file-send-lark-cli --help
echo.
