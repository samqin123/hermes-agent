---
name: feishu-file-send-lark-cli
description: 使用 lark-cli 命令行发送本地文件到飞书聊天会话（群聊/DM）
version: 1.0.0
---

# Skill: 飞书文件发送（lark-cli 直接调用）

## 用途
通过 lark-cli 命令行工具发送本地文件到飞书聊天会话（群聊或私信）。

## 前置条件
1. 已安装 lark-cli 并完成设备码登录授权
2. lark-cli 路径：`~/.npm/_npx/.../@larksuite/cli/scripts/run.js`
3. 文件在本地存在且可读

## 步骤

### 1. 获取目标会话的 chat_id
```bash
# 方法 A：搜索最近消息找到当前会话
node <lark-cli-path>/scripts/run.js im +messages-search --query "" --format json

# 从返回的 messages[0].chat_id 提取
```

```bash
# 方法 B：列出所有群聊（不含私信）
node <lark-cli-path>/scripts/run.js im chats list --format json
```

### 2. 复制文件到 lark-cli 工作目录
`--file` 参数要求相对路径且在當前目录，必须复制：
```python
import shutil
shutil.copy2(源文件路径, lark_cli目录/目标文件名.md)
```

### 3. 发送文件
```bash
# 群聊
node <lark-cli-path>/scripts/run.js im +messages-send \
  --as user \
  --chat-id <chat_id> \
  --file <filename>

# 私信（user_id 类型，需要对方租户内 ID）
node <lark-cli-path>/scripts/run.js im +messages-send \
  --as user \
  --user-id <user_id> \
  --file <filename>
```

添加 `--format json` 可获取返回的 `message_id`。

## 关键参数说明
- `--as user` — 使用用户身份发送（默认为 bot）
- `--chat-id` — 群聊或会话 ID（oc_xxx）
- `--user-id` — 私信接收方用户 ID（租户内，非 open_id）
- `--file` — 本地文件路径（相对路径，当前目录）
- `--content` — 手动指定消息内容 JSON（自动发送时不需要）

## 注意事项
- 跨租户 DM 会报错 `open_id cross app`，此时无法用 `--user-id` 发送
- DM 会话的 `chat_id` 可通过 `+messages-search` 搜索自己消息获得
- `--file` 会自动上传并返回 `file_key`，无需手动调用上传接口
- 文件类型自动识别：`.md` → 文档，`.png/.jpg` → 图片，其他 → 通用文件

## 示例（Python 调用）
```python
import subprocess, shutil, os

base = '/Users/sammini/.npm/_npx/.../@larksuite/cli'
run_js = os.path.join(base, 'scripts/run.js')

# 1) 获取 chat_id（从搜索或预先知道）
chat_id = 'oc_e92ded0f5dbeecd5601c811bd2247ddf'

# 2) 复制文件
src = '/path/to/report.md'
dst = os.path.join(base, 'report.md')
shutil.copy2(src, dst)

# 3) 发送
result = subprocess.run(
    ['node', run_js, 'im', '+messages-send',
     '--as', 'user',
     '--chat-id', chat_id,
     '--file', 'report.md',
     '--format', 'json'],
    capture_output=True, text=True, timeout=60,
    cwd=base
)
print(result.stdout)  # 包含 message_id
```

## 故障排查
| 现象 | 原因 | 解决 |
|------|------|------|
| `unknown command "chat"` | 命令是 `im chats list` | 改用正确路径 |
| `open_id cross app` | 跨租户 DM | 用 `chat_id` 替代 `user-id` |
| `FileNotFoundError` | 文件不在当前目录 | 复制到 lark-cli 目录 |
| RC=1 无输出 | 缺少 `--as user` 或参数错误 | 补全必需参数 |

---

**创建时间**: 2026-04-16
**适用场景**: 飞书文件发送（MD/PDF/图片等）