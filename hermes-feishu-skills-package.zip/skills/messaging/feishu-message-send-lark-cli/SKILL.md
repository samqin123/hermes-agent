---
name: feishu-message-send-lark-cli
description: 使用 lark-cli 发送文本/富文本消息到飞书会话（群聊或私信）
version: 1.0.0
---

# Skill: 飞书消息发送（lark-cli 直接调用）

## 用途
通过 lark-cli 命令行向飞书聊天会话发送纯文本或富文本消息，支持群聊和私信场景。

## 前置条件
1. 已安装 lark-cli 并完成设备码登录授权
2. lark-cli 路径：`~/.npm/_npx/.../@larksuite/cli/scripts/run.js`
3. 已获取目标会话的 `chat_id` 或接收人 `user_id`

## 步骤

### 1. 获取目标会话标识
```bash
# 方法 A：搜索最近消息获取当前 DM 的 chat_id（推荐用于私信）
node <lark-cli-path>/scripts/run.js im +messages-search --query "" --format json
# 从 messages[0].chat_id 提取

# 方法 B：列出所有群聊（不含私信）
node <lark-cli-path>/scripts/run.js im chats list --format json
# 从返回的 chat.id 提取群聊 chat_id
```

### 2. 发送纯文本消息
```bash
# 发送到群聊或已知会话（使用 chat_id）
node <lark-cli-path>/scripts/run.js im +messages-send \
  --as user \
  --chat-id <chat_id> \
  --content "{\"text\":\"消息内容\"}" \
  --format json

# 发送到私信（同一租户内，使用 user_id）
node <lark-cli-path>/scripts/run.js im +messages-send \
  --as user \
  --user-id <user_id> \
  --content "{\"text\":\"消息内容\"}"
```

### 3. 发送富文本消息（At / 链接 / 加粗等）
```bash
# At 某人（需要其 user_id，同一租户）
node run.js im +messages-send \
  --as user \
  --chat-id <chat_id> \
  --content "{\"text\":\"<at id=\\\"u123\\\">姓名</at> 请查看\", \"mention\":\"open\"}"

# 富文本 JSON 完整格式（参考飞书 OpenAPI messanger v3）
# text 字段支持 <at>、<a href>、<b>、<i>、<u>、<image> 等标签
```

### 4. 回复指定消息
```bash
# 通过 root_id 回复某条消息
node run.js im +messages-send \
  --as user \
  --chat-id <chat_id> \
  --content "{\"text\":\"回复内容\"}" \
  --root-id <message_id_to_reply>
```

## 关键参数说明
- `--as user` — 使用用户身份发送（默认 bot）
- `--chat-id` — 会话 ID（群聊或 DM 会话，格式 `oc_xxx`）
- `--user-id` — 接收人用户 ID（租户内，非 open_id，仅同租户可用）
- `--content` — 消息内容 JSON 字符串，最少包含 `{"text":"..."}` 字段
- `--root-id` — 被回复消息的 `message_id`，用于线程回复
- `--format json` — 输出 JSON 格式，便于解析返回的 `message_id`

## 获取 user_id 的方法
```bash
# 通过通讯录搜索（需要权限）
node run.js contact search --keyword "姓名" --format json
# 从 user.id 字段获取（格式：ou_xxx）

# 通过会话内消息的 sender 字段反查
node run.js im +messages-search --query "" --format json | jq '.messages[0].sender'
```

## Python 调用示例
```python
import subprocess, os, json

base = '/Users/sammini/.npm/_npx/.../@larksuite/cli'
run_js = os.path.join(base, 'scripts/run.js')

def send_text(chat_id: str, text: str, user_id: str = None) -> str:
    """发送纯文本消息，返回 message_id"""
    content = {"text": text}
    cmd = [
        'node', run_js, 'im', '+messages-send',
        '--as', 'user',
        '--format', 'json'
    ]
    if chat_id:
        cmd.extend(['--chat-id', chat_id])
    if user_id:
        cmd.extend(['--user-id', user_id])
    cmd.extend(['--content', json.dumps(content, ensure_ascii=False)])

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, cwd=base)
    data = json.loads(result.stdout)
    return data['message']['message_id']

def send_text_with_mention(chat_id: str, text: str, mention_user_id: str, mention_name: str) -> str:
    """发送 At 消息"""
    mention_tag = f'<at id="{mention_user_id}">{mention_name}</at>'
    content = {
        "text": f'{mention_tag} {text}',
        "mention": "open"  # 启用 @ 解析
    }
    # ... 同上构造命令
```

## chat_id vs user_id 选择指南
| 场景 | 推荐参数 | 说明 |
|------|----------|------|
| 已知群聊 | `--chat-id` | 群聊 `chat_id` 从 `im chats list` 获取 |
| 当前 DM 会话 | `--chat-id` | 通过 `+messages-search` 获取当前对话的 `chat_id`（跨租户也有效） |
| 同租户私信（已知对方 user_id） | `--user-id` | 仅当发送方与接收方在同一租户内可用 |
| 跨租户 DM | `--chat-id` | 必须使用会话 `chat_id`，`--user-id` 会报 `open_id cross app` |

**最佳实践**：优先使用 `--chat-id`，兼容性最好（群聊 + DM + 跨租户）。

## 富文本消息格式示例
```json
{
  "text": "你好 <at id=\\\"ou_123\\\">张三</at>，请查看报告：<a href=\\\"https://example.com\\\">链接</a>",
  "mention": "open"
}
```

支持的 HTML-like 标签：
- `<at id="ou_xxx">姓名</at>` — At 用户
- `<a href="URL">链接文本</a>` — 超链接
- `<b>粗体</b>` / `<i>斜体</i>` / `<u>下划线</u>` — 文本样式
- `<image image_key="img_xxx">` — 内联图片（需先上传获取 `image_key`）
- `<rich text>...</rich>` — 高级富文本（卡片等，需完整 OpenAPI 格式）

## 注意事项
- 消息内容必须使用 JSON 字符串，需用 `json.dumps(ensure_ascii=False)` 转义
- 私信跨租户场景禁用 `--user-id`，务必改用 `--chat-id`
- `--as user` 表示以"用户"身份发送（非 bot），需要权限 `im:message:send_as_user`
- 消息长度限制：普通文本 ≤ 5000 字符，富文本 ≤ 10000 字符（含标签）
- 频繁发送可能触发频控（群聊 ≤ 20 条/秒，私信 ≤ 5 条/秒）
- 使用 `--format json` 可得到结构化返回，包含 `message_id`、`chat_id`、`sender` 等

## 故障排查
| 现象 | 原因 | 解决 |
|------|------|------|
| `invalid chat_id` | chat_id 格式错误或会话不存在 | 通过 `im chats list` 或 `+messages-search` 重新获取 |
| `open_id cross app` | 跨租户使用 `--user-id` | 改用 `--chat-id` |
| `permission denied` | 缺少 `im:message:send_as_user` 权限 | 设备码授权时勾选 "消息发送" 权限 |
| `unknown field "text"` | `--content` 不是合法 JSON | 确保 `{"text":"..."}` 格式正确并转义 |
| `message too long` | 文本超限 | 分段发送或使用文件发送 |

## 组合使用示例
```bash
# 1. 先创建文档
node run.js docs +create --title "日报" --folder / --markdown @report.md --format json

# 2. 获取 doc_id 后发送文档到会话
node run.js im +messages-send --as user --chat-id oc_xxx --file report.md

# 3. 发送文字说明
node run.js im +messages-send \
  --as user \
  --chat-id oc_xxx \
  --content "{\"text\":\"已发送日报，请查收\"}"
```

---

**创建时间**: 2026-04-16
**适用场景**: 飞书消息发送、群聊通知、DM 沟通、At 提醒
